<?php
include 'config.php';

$success = '';
$error = '';
$step = 1; // Step 1: Email, Step 2: Security Question, Step 3: New Password

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_POST['check_email'])) {
        $email = $conn->real_escape_string($_POST['email']);
        $stmt = $conn->prepare("SELECT id, full_name, email FROM users WHERE email = ?");
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $result = $stmt->get_result();
        
        if ($result->num_rows == 1) {
            $_SESSION['reset_user'] = $result->fetch_assoc();
            $step = 2;
        } else {
            $error = "Email not found in our system.";
        }
    } elseif (isset($_POST['verify_security'])) {
        // For simplicity, using license number as security verification
        $license = $conn->real_escape_string($_POST['license_number']);
        $user_id = $_SESSION['reset_user']['id'];
        
        $stmt = $conn->prepare("SELECT license_number FROM users WHERE id = ?");
        $stmt->bind_param("i", $user_id);
        $stmt->execute();
        $result = $stmt->get_result();
        $user_data = $result->fetch_assoc();
        
        if ($user_data && $user_data['license_number'] == $license) {
            $_SESSION['reset_verified'] = true;
            $step = 3;
        } else {
            $error = "License number doesn't match our records.";
            $step = 2;
        }
    } elseif (isset($_POST['reset_password'])) {
        if (isset($_SESSION['reset_verified']) && $_SESSION['reset_verified']) {
            $new_password = $_POST['new_password'];
            $confirm_password = $_POST['confirm_password'];
            
            if (strlen($new_password) < 6) {
                $error = "Password must be at least 6 characters.";
                $step = 3;
            } elseif ($new_password !== $confirm_password) {
                $error = "Passwords do not match.";
                $step = 3;
            } else {
                $hashed = password_hash($new_password, PASSWORD_DEFAULT);
                $user_id = $_SESSION['reset_user']['id'];
                
                $stmt = $conn->prepare("UPDATE users SET password = ? WHERE id = ?");
                $stmt->bind_param("si", $hashed, $user_id);
                
                if ($stmt->execute()) {
                    $success = "Password reset successful! You can now login.";
                    unset($_SESSION['reset_user']);
                    unset($_SESSION['reset_verified']);
                    $step = 4; // Success step
                } else {
                    $error = "Failed to reset password. Please try again.";
                    $step = 3;
                }
            }
        } else {
            $error = "Security verification failed.";
            $step = 1;
        }
    }
}

// Check session for step navigation
if (isset($_SESSION['reset_user']) && !isset($_POST['check_email'])) {
    $step = 2;
}
if (isset($_SESSION['reset_verified']) && !isset($_POST['verify_security'])) {
    $step = 3;
}
?>

<?php include 'header.php'; ?>

<div class="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100 flex items-center justify-center py-12 px-4">
    <div class="max-w-md w-full">
        <div class="text-center mb-8">
            <div class="inline-flex items-center justify-center w-16 h-16 bg-indigo-100 rounded-2xl mb-4">
                <i class="fas fa-key text-indigo-600 text-2xl"></i>
            </div>
            <h2 class="text-3xl font-bold text-slate-900">Reset Password</h2>
            <p class="text-slate-500 mt-2">
                <?php 
                if ($step == 1) echo "Enter your email to get started";
                elseif ($step == 2) echo "Verify your identity";
                elseif ($step == 3) echo "Create your new password";
                elseif ($step == 4) echo "Password reset complete";
                ?>
            </p>
        </div>

        <div class="bg-white rounded-2xl shadow-xl p-8 border border-slate-200">
            <?php if ($success): ?>
                <div class="mb-6 bg-green-50 border border-green-200 text-green-700 px-4 py-3 rounded-lg flex items-center gap-2">
                    <i class="fas fa-check-circle"></i>
                    <span><?php echo $success; ?></span>
                </div>
            <?php endif; ?>

            <?php if ($error): ?>
                <div class="mb-6 bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-lg flex items-center gap-2">
                    <i class="fas fa-exclamation-circle"></i>
                    <span><?php echo $error; ?></span>
                </div>
            <?php endif; ?>

            <?php if ($step == 1): ?>
            <!-- Step 1: Email -->
            <form method="POST" action="" class="space-y-5">
                <div>
                    <label class="block text-sm font-medium text-slate-700 mb-2">Email Address</label>
                    <div class="relative">
                        <div class="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                            <i class="fas fa-envelope text-slate-400"></i>
                        </div>
                        <input type="email" name="email" required
                               class="block w-full pl-10 pr-3 py-3 border border-slate-300 rounded-lg focus:ring-2 focus:ring-indigo-500 outline-none"
                               placeholder="you@example.com">
                    </div>
                </div>
                <button type="submit" name="check_email" class="w-full bg-indigo-600 hover:bg-indigo-700 text-white font-medium py-3 rounded-lg">
                    Continue
                </button>
            </form>

            <?php elseif ($step == 2): ?>
            <!-- Step 2: Security Verification -->
            <form method="POST" action="" class="space-y-5">
                <p class="text-sm text-slate-600 mb-4">
                    Hello <strong><?php echo $_SESSION['reset_user']['full_name']; ?></strong>, 
                    please verify your identity by entering your driver's license number.
                </p>
                <div>
                    <label class="block text-sm font-medium text-slate-700 mb-2">Driver's License Number</label>
                    <div class="relative">
                        <div class="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                            <i class="fas fa-id-card text-slate-400"></i>
                        </div>
                        <input type="text" name="license_number" required
                               class="block w-full pl-10 pr-3 py-3 border border-slate-300 rounded-lg focus:ring-2 focus:ring-indigo-500 outline-none"
                               placeholder="Enter your license number">
                    </div>
                </div>
                <button type="submit" name="verify_security" class="w-full bg-indigo-600 hover:bg-indigo-700 text-white font-medium py-3 rounded-lg">
                    Verify Identity
                </button>
            </form>

            <?php elseif ($step == 3): ?>
            <!-- Step 3: New Password -->
            <form method="POST" action="" class="space-y-5">
                <div>
                    <label class="block text-sm font-medium text-slate-700 mb-2">New Password</label>
                    <div class="relative">
                        <div class="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                            <i class="fas fa-lock text-slate-400"></i>
                        </div>
                        <input type="password" name="new_password" required minlength="6"
                               class="block w-full pl-10 pr-3 py-3 border border-slate-300 rounded-lg focus:ring-2 focus:ring-indigo-500 outline-none"
                               placeholder="New password">
                    </div>
                    <p class="text-xs text-slate-500 mt-1">Minimum 6 characters</p>
                </div>
                <div>
                    <label class="block text-sm font-medium text-slate-700 mb-2">Confirm New Password</label>
                    <div class="relative">
                        <div class="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                            <i class="fas fa-lock text-slate-400"></i>
                        </div>
                        <input type="password" name="confirm_password" required minlength="6"
                               class="block w-full pl-10 pr-3 py-3 border border-slate-300 rounded-lg focus:ring-2 focus:ring-indigo-500 outline-none"
                               placeholder="Confirm password">
                    </div>
                </div>
                <button type="submit" name="reset_password" class="w-full bg-indigo-600 hover:bg-indigo-700 text-white font-medium py-3 rounded-lg">
                    Reset Password
                </button>
            </form>

            <?php elseif ($step == 4): ?>
            <!-- Step 4: Success -->
            <div class="text-center py-6">
                <div class="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
                    <i class="fas fa-check text-green-600 text-2xl"></i>
                </div>
                <h3 class="text-lg font-bold text-slate-900 mb-2">Password Reset Successful!</h3>
                <p class="text-slate-600 mb-6">You can now login with your new password.</p>
                <a href="login.php" class="inline-block bg-indigo-600 hover:bg-indigo-700 text-white px-8 py-3 rounded-lg font-medium">
                    Go to Login
                </a>
            </div>
            <?php endif; ?>

            <?php if ($step < 4): ?>
            <div class="mt-6 text-center">
                <a href="login.php" class="text-sm text-indigo-600 hover:text-indigo-700">
                    <i class="fas fa-arrow-left mr-1"></i> Back to Login
                </a>
            </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<?php include 'footer.php'; ?>