import React from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery } from '@tanstack/react-query';
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { format } from "date-fns";
import { Link } from 'react-router-dom';
import { Car, CalendarDays, ArrowRight, Clock, CheckCircle2, XCircle } from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";

export default function MyRentals() {
  const [user, setUser] = React.useState(null);

  React.useEffect(() => {
    base44.auth.me().then(setUser).catch(() => base44.auth.redirectToLogin());
  }, []);

  const { data: rentals, isLoading } = useQuery({
    queryKey: ['my-rentals'],
    queryFn: async () => {
      // Entities list automatically filters by created_by for non-admins? 
      // Base44 documentation says "User entity has special built-in security rules... Regular users can only view and update their own user record"
      // But for generic entities, usually they return all records unless filtered.
      // However, usually we filter by created_by = user.email (or user.id). 
      // Assuming list() returns everything, we filter client side for safety if not handled by backend rules.
      // But actually, typically Base44 list() returns all if user has permission.
      // Let's filter by the current user's email just to be safe and correct.
      if (!user) return [];
      const allRentals = await base44.entities.Rental.list('-created_date');
      return allRentals.filter(r => r.created_by === user.email);
    },
    enabled: !!user
  });

  const getStatusColor = (status) => {
    switch(status) {
      case 'active': return 'bg-green-100 text-green-700 border-green-200';
      case 'completed': return 'bg-slate-100 text-slate-700 border-slate-200';
      case 'cancelled': return 'bg-red-100 text-red-700 border-red-200';
      default: return 'bg-indigo-100 text-indigo-700 border-indigo-200';
    }
  };

  const getStatusIcon = (status) => {
    switch(status) {
      case 'active': return CheckCircle2;
      case 'completed': return Clock;
      case 'cancelled': return XCircle;
      default: return Car;
    }
  };

  if (!user) return null; // Redirect handled in useEffect

  return (
    <div className="min-h-screen bg-slate-50 py-12">
      <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col md:flex-row md:items-center justify-between mb-8 gap-4">
          <div>
            <h1 className="text-3xl font-bold text-slate-900">My Rentals</h1>
            <p className="text-slate-500 mt-1">Manage your upcoming and past trips.</p>
          </div>
          <Button asChild className="bg-indigo-600 hover:bg-indigo-700">
            <Link to="/Catalog">Book New Car</Link>
          </Button>
        </div>

        {isLoading ? (
          <div className="space-y-4">
            {[1, 2, 3].map(i => (
              <div key={i} className="bg-white p-6 rounded-xl border border-slate-200">
                <div className="flex gap-4">
                  <Skeleton className="w-32 h-24 rounded-lg" />
                  <div className="flex-1 space-y-2">
                    <Skeleton className="w-1/3 h-6" />
                    <Skeleton className="w-1/4 h-4" />
                  </div>
                </div>
              </div>
            ))}
          </div>
        ) : rentals?.length > 0 ? (
          <div className="space-y-4">
            {rentals.map((rental) => {
              const StatusIcon = getStatusIcon(rental.status);
              return (
                <div key={rental.id} className="bg-white rounded-2xl p-6 border border-slate-200 shadow-sm hover:shadow-md transition-shadow">
                  <div className="flex flex-col md:flex-row gap-6">
                    {/* Car Image */}
                    <div className="w-full md:w-48 h-32 bg-slate-100 rounded-xl overflow-hidden flex-shrink-0">
                      {rental.car_details?.image_url ? (
                        <img 
                          src={rental.car_details.image_url} 
                          alt="Car" 
                          className="w-full h-full object-cover"
                        />
                      ) : (
                        <div className="w-full h-full flex items-center justify-center text-slate-400">
                          <Car className="w-8 h-8" />
                        </div>
                      )}
                    </div>

                    {/* Rental Details */}
                    <div className="flex-grow flex flex-col justify-between">
                      <div className="flex flex-col md:flex-row justify-between items-start gap-4">
                        <div>
                          <h3 className="text-xl font-bold text-slate-900">
                            {rental.car_details?.make} {rental.car_details?.model}
                          </h3>
                          <div className="flex items-center gap-4 mt-2 text-sm text-slate-500">
                            <div className="flex items-center gap-1.5">
                              <CalendarDays className="w-4 h-4" />
                              <span>
                                {format(new Date(rental.start_date), 'MMM d')} - {format(new Date(rental.end_date), 'MMM d, yyyy')}
                              </span>
                            </div>
                            <span className="w-1 h-1 rounded-full bg-slate-300" />
                            <span className="font-medium text-slate-900">
                              ${rental.total_price} Total
                            </span>
                          </div>
                        </div>
                        <Badge className={`${getStatusColor(rental.status)} border px-3 py-1`}>
                          <StatusIcon className="w-3.5 h-3.5 mr-1.5" />
                          {rental.status.charAt(0).toUpperCase() + rental.status.slice(1)}
                        </Badge>
                      </div>

                      <div className="mt-6 flex justify-end">
                        <Button variant="ghost" className="text-indigo-600 hover:text-indigo-700 hover:bg-indigo-50" asChild>
                          <Link to={`/CarDetails?id=${rental.car_id}`}>
                            Rent Again <ArrowRight className="w-4 h-4 ml-2" />
                          </Link>
                        </Button>
                      </div>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        ) : (
          <div className="text-center py-24 bg-white rounded-3xl border border-slate-200 border-dashed">
            <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-indigo-50 mb-4">
              <Car className="h-8 w-8 text-indigo-500" />
            </div>
            <h3 className="text-lg font-bold text-slate-900">No rentals yet</h3>
            <p className="text-slate-500 mt-2 mb-6">You haven't booked any cars yet. Start your journey today.</p>
            <Button asChild className="bg-indigo-600 hover:bg-indigo-700">
              <Link to="/Catalog">Browse Cars</Link>
            </Button>
          </div>
        )}
      </div>
    </div>
  );
}